﻿using Microsoft.AspNetCore.Identity;

namespace JWTAuthentication.Authentication
{
    public class ApplicationUser: IdentityUser
    {
    }
}
